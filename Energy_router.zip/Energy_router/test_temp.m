mpc = case85main_ac;
fid = fopen('exp.txt','wt');
bus_Data=mpc.gencost;
% fprintf(fid,'        [%d, %d, %.4f, %.4f, %.4f, %.4f, %d, %.4f, %.4f, %.4f, %d, %.4f, %.4f],\n',bus_Data');
% fprintf(fid,'        [%d, %.4f, %.4f, %.4f, %.4f, %.4f, %.4f, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d],\n',bus_Data');
% fprintf(fid,'        [%d, %d, %f, %f, %f, %d, %d, %d, %d, %d, %d, %d, %d],\n',bus_Data');
fprintf(fid,'        [%d, %d, %d, %d, %.4f, %d, %d],\n',bus_Data');
fclose(fid);
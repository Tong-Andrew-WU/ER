import numpy as np
def sum(a, b):
    return np.sum(a + b)
function lambda_main_new=update_lambda_main(lambda_main, z_main1, z_main2, z_r1, z_r2)
lambda_main_new=lambda_main;
rho=1e4;
lambda_main_new(:,1)=lambda_main(:,1)+rho*(z_main1-z_r1);
lambda_main_new(:,2)=lambda_main(:,2)+rho*(z_main2-z_r2);

end
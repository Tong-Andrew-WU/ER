function [x_sub, z_r, fuel_cost, Vm]=update_x_sub(z_main, x0, lambda, mpcac, Sub_id)

% z=z2;
% lambda=lambda2;
% pho_max=pho2_max;

ngen=size(mpcac.gen,1);
nbus=size(mpcac.bus,1);

Tamin=-2*pi*ones(1,nbus);
Tamax=2*pi*ones(1,nbus);
%%%% [PG_AC, QG_AC, VM_AC, VA_AC]
% x0 = [mpcac.gen(:,2)', mpcac.gen(:,3)', mpcac.bus(:, 8)', mpcac.bus(:, 9)'];
lb = [mpcac.gen(:,10)', mpcac.gen(:,5)', mpcac.bus(:,13)', Tamin];
ub = [mpcac.gen(:,9)', mpcac.gen(:,4)', mpcac.bus(:,12)', Tamax];

para=get_para(Sub_id);
Aeq=para.Aeq;
beq=para.beq;

A=para.A;
b=para.b;

options = optimset('MaxIter',3000, 'MaxFunEvals',300000,'TolFun', 1e-8, 'Algorithm','sqp');
[x, fval, exitflag, output]=fmincon(@(x)wobjfun_AC(x, mpcac, z_main, lambda), x0, A, b, Aeq, beq, lb, ub,...
    @(x)wconfun_AC(x, mpcac, Sub_id), options);

x_sub=x;
Vm=x(2*ngen+1: 2*ngen+nbus)';
Va=x(2*ngen+nbus+1: 2*ngen+2*nbus)';
Vcplx=Vm.*exp(1j.*Va);
W=(Vcplx*Vcplx');
z_r=[real(W(1, 1)-W(1, 2)); imag(W(1, 1)-W(1, 2)); W(1, 1); W(2, 2)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ngen=size(mpcac.gen,1);
PG=x(1:ngen);
pr=mpcac.gencost(:,5:7);
fuel_cost=(PG.*PG)*pr(:,1)+PG*(pr(:,2))+sum(pr(:,3));
Vm=x(2*ngen+1: 2*ngen+nbus);
 end

% end
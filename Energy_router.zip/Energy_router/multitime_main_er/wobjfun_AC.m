function f=wobjfun_AC(x, mpcac, z_main, lambda)
pr=mpcac.gencost(:,5:7);  % x implies the cost of the generator.
ngen=size(mpcac.gen,1);
nbus=size(mpcac.bus,1);
rho=1e4;
PG=x(1:ngen);
Vm=x(2*ngen+1: 2*ngen+nbus)';
Va=x(2*ngen+nbus+1: 2*ngen+2*nbus)';
Vcplx=Vm.*exp(1j.*Va);
W=(Vcplx*Vcplx');
z_r=[real(W(1, 1)-W(1, 2)); imag(W(1, 1)-W(1, 2)); W(1, 1); W(2, 2)];



f1=(PG.*PG)*pr(:,1)+PG*(pr(:,2))+sum(pr(:,3));
f2=lambda'*(z_r-z_main)+rho / 2*((z_r-z_main)'*(z_r-z_main)); %define lambda, rho, A, z
f=f1+f2;
end
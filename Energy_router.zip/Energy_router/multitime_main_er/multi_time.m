load('demand_p_renew.mat')
funs = load_mpc;
[PD_real_main, QD_real_main]=funs.main_mpc(active_power, reactive_power);
[PD_real_sub1, QD_real_sub1]=funs.sub1_mpc(active_power, reactive_power, active_powerDC1, renew1);
[PD_real_sub2, QD_real_sub2]=funs.sub2_mpc(active_power, reactive_power, active_powerDC2, renew2);

Time=480;
fuel_cost_main=zeros(Time, 1);
fuel_cost_sub1=zeros(Time, 1);
fuel_cost_sub2=zeros(Time, 1);

mpc_ext = case85main_ac;
mpcac1_ext = case85sub_ac1;
mpcac2_ext = case85sub_ac2;
Vm1_sub1=zeros(Time, size(mpcac1_ext.bus, 1));
Vm2_sub2=zeros(Time, size(mpcac2_ext.bus, 1));

for i=1:Time


mpc_ext.bus(:, 3)=(PD_real_main(i, :))';
mpc_ext.bus(:, 4)=(QD_real_main(i, :))';

mpcac1_ext.bus(:, 3)=(PD_real_sub1(i, :)*20)';
mpcac1_ext.bus(:, 4)=(QD_real_sub1(i, :)*20)';

mpcac2_ext.bus(:, 3)=(PD_real_sub2(i, :)*20)';
mpcac2_ext.bus(:, 4)=(QD_real_sub2(i, :)*10)';

mpc_main=ext2int(mpc_ext);
mpcac1=ext2int(mpcac1_ext);
mpcac2=ext2int(mpcac2_ext);


[fuel_cost0, fuel_cost1, fuel_cost2, Vm1, Vm2]=main_cvx(mpc_main, mpcac1, mpcac2);
fuel_cost_main(i)=fuel_cost0;
fuel_cost_sub1(i)=fuel_cost1;
fuel_cost_sub2(i)=fuel_cost2;
Vm1_sub1(i,:)=Vm1;
Vm2_sub2(i,:)=Vm2;
end
save('multitime_main_er.mat', 'fuel_cost_main', 'fuel_cost_sub1', 'fuel_cost_sub2', 'Vm1_sub1', 'Vm2_sub2')
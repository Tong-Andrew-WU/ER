function lambda_sub_new=update_lambda_sub(lambda_sub, z_main, z_r)
rho=1e4;
lambda_sub_new=lambda_sub+rho*(z_r-z_main);
end
function para=get_para(ID)
         if ID==1
             mpc= case85sub_ac1;
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             index_P=1:size(mpc.bus, 1);
             P_index_ac=index_P(1:25);
             P_index_dc=index_P(26:end);
             P_index_ac(find(mpc.bus(:,1)==33))=[];
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             Q_index_ac=P_index_ac+size(mpc.bus, 1);
             Q_index_dc=P_index_dc+size(mpc.bus, 1);
             para.P_acidx=P_index_ac;
             para.Q_acidx=Q_index_ac;
             para.P_dcidx=P_index_dc;
             para.Q_dcidx=Q_index_dc;
             Qmat=zeros(18, size(mpc.bus, 1));
             mpcint=ext2int(mpc);
             row=mpcint.branch(25:end,1);
             col=mpcint.branch(25:end,2);
             index_row=sub2ind(size(Qmat), 1:18, row');
             index_col=sub2ind(size(Qmat), 1:18, col');
             Qmat(index_row)=1;
             Qmat(index_col)=-1;
             para.Qmat=Qmat;
%              %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%% [PG_AC, QG_AC, VM_AC, VA_AC]
%           x0 = [mpcac.gen(:,2)', mpcac.gen(:,3)', mpcac.bus(:, 8)', mpcac.bus(:, 9)'];
             Aeq=zeros(18, 2*(size(mpc.bus, 1)+size(mpc.gen, 1)));
             Aeq(:,(2*size(mpc.gen, 1)+size(mpc.bus, 1)+1):2*(size(mpc.bus, 1)+size(mpc.gen, 1)))=Qmat;
             beq=zeros(18, 1);
             para.Aeq=Aeq;
             para.beq=beq;
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             Vm2D=zeros(4, size(mpc.bus, 1));
             Vm2d=zeros(4, size(mpc.bus, 1));
             Vm2D(:,18:21)=diag(ones(4,1));
             Vm2d(:,22:25)=diag(ones(4,1));
             Vm2D_d=[Vm2D;Vm2d];
             Vm2D_d(1:4, 26)=-2/sqrt(3);
             Vm2D_d(5:8, 27)=-2/sqrt(3);
             A=zeros(8, 2*(size(mpc.bus, 1)+size(mpc.gen, 1)));
             A(:,(2*size(mpc.gen, 1)+1):(2*size(mpc.gen, 1)+size(mpc.bus, 1)))=Vm2D_d;
             b=zeros(8, 1);
             para.A=A;
             para.b=b;
             
         end
         if ID==2
             mpc= case85sub_ac2;
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             index_P=1:size(mpc.bus, 1);
             P_index_ac=index_P(1:27);
             P_index_dc=index_P(28:end);
             P_index_ac(find(mpc.bus(:,1)==60))=[];
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             Q_index_ac=P_index_ac+size(mpc.bus, 1);
             Q_index_dc=P_index_dc+size(mpc.bus, 1);
             para.P_acidx=P_index_ac;
             para.Q_acidx=Q_index_ac;
             para.P_dcidx=P_index_dc;
             para.Q_dcidx=Q_index_dc;
             Qmat=zeros(22, size(mpc.bus, 1));
             mpcint=ext2int(mpc);
             row=mpcint.branch(27:end,1);
             col=mpcint.branch(27:end,2);
             index_row=sub2ind(size(Qmat), 1:22, row');
             index_col=sub2ind(size(Qmat), 1:22, col');
             Qmat(index_row)=1;
             Qmat(index_col)=-1;
             para.Qmat=Qmat;
%              %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             Aeq=zeros(22, 2*(size(mpc.bus, 1)+size(mpc.gen, 1)));
             Aeq(:,(2*size(mpc.gen, 1)+size(mpc.bus, 1)+1):2*(size(mpc.bus, 1)+size(mpc.gen, 1)))=Qmat;
             beq=zeros(22, 1);
             para.Aeq=Aeq;
             para.beq=beq;
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             Vm2D=zeros(5, size(mpc.bus, 1));
             Vm2d=zeros(5, size(mpc.bus, 1));
             Vm2D(:,18:22)=diag(ones(5,1));
             Vm2d(:,23:27)=diag(ones(5,1));
             Vm2D_d=[Vm2D;Vm2d];
             Vm2D_d(1:5, 28)=-2/sqrt(3);
             Vm2D_d(6:10, 29)=-2/sqrt(3);
             A=zeros(10, 2*(size(mpc.bus, 1)+size(mpc.gen, 1)));
             A(:,(2*size(mpc.gen, 1)+1):(2*size(mpc.gen, 1)+size(mpc.bus, 1)))=Vm2D_d;
             b=zeros(10, 1);
             para.A=A;
             para.b=b;
             
         end
end

ID=2;
mpc=mpcac2;
x=x_sub2;

ngen=size(mpc.gen,1);
nbus=size(mpc.bus,1);
PG=x(1:ngen)';
QG=x(ngen+1: 2*ngen)';
Vm=x(2*ngen+1: 2*ngen+nbus)';
Va=x(2*ngen+nbus+1: 2*ngen+2*nbus)';
Ybus = makeYbus(mpc);

para=get_para(ID);

%%%%nonlinear equality constraint%%%%
baseMVA=mpc.baseMVA;
gen_x=mpc.gen;
gen_x(:,2)=PG;
gen_x(:,3)=QG;
Sbus=makeSbus(baseMVA, mpc.bus, gen_x);
Vcplx=Vm.*exp(1j.*Va);
mis=Sbus-Vcplx.*conj(Ybus*Vcplx);
mis_r=[real(mis);imag(mis)];


Pidx=[para.P_acidx, para.P_dcidx];
Qidx=para.Q_acidx;


numPidx=size(Pidx, 2);
numQidx=size(Qidx, 2);


ceq=zeros(numPidx+numQidx,1);
ceq(1:numPidx)=mis_r(Pidx);
ceq(numPidx+1:numPidx+numQidx)=mis_r(Qidx);





function [gamma1, gamma2]=get_gamma(z_main1, z_main2, z_r1, z_r2)
          gamma1=norm(z_main1-z_r1, inf);
          gamma2=norm(z_main2-z_r2, inf);
end
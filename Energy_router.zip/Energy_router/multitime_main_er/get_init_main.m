function lambda_main=get_init_main()
lambda_main=zeros(4,2);
end
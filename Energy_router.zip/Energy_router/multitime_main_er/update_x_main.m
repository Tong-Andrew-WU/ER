function [z_main1, z_main2, fuel]=update_x_main(z_r1, z_r2, lambda, mpc)

rho=1e4;
index=ones(55, 1);
index(34)=0;
index(48)=0;

Index_gen=zeros(size(mpc.gen(:,1),1), size(mpc.bus(:,1),1));
Select_index=(1:size(mpc.gen(:,1),1))' + (mpc.gen(:,1)-1)*size(mpc.gen(:,1),1);
Index_gen(Select_index)=1;

Ybus=makeYbus(mpc);
Gbus=real(Ybus);
Gdiag=diag(Gbus);
Goffdiag=Gbus-diag(Gdiag);

Bbus=imag(Ybus);
Bdiag=diag(Bbus);
Boffdiag=Bbus-diag(Bdiag);

VMIN2=mpc.bus(:,13).^2;
VMAX2=mpc.bus(:,12).^2;
Pmax=mpc.gen(:,9);
Pmin=mpc.gen(:,10);
Qmax=mpc.gen(:,4);
Qmin=mpc.gen(:,5);
Sload=mpc.bus(:,3)+1j*mpc.bus(:,4);
pr=mpc.gencost(:,5:7); 

n=size(mpc.bus, 1);
m=size(mpc.gen, 1);

cvx_begin sdp quiet
variable  W(n, n) hermitian
variable  Pg(m)
variable  Qg(m)

minimize ((Pg.*Pg)'*pr(:,1)+Pg'*pr(:,2)+sum(pr(:,3))+...
    lambda(:, 1)'*([real(W(33, 33)-W(33, 34)); imag(W(33, 33)-W(33, 34)); W(33, 33); W(34, 34)]-z_r1)+...
    lambda(:, 2)'*([real(W(45, 45)-W(45, 48)); imag(W(45, 45)-W(45, 48)); W(45, 45); W(48, 48)]-z_r2)+...
   rho/2*sum_square_abs([real(W(33, 33)-W(33, 34)); imag(W(33, 33)-W(33, 34)); W(33, 33); W(34, 34)]-z_r1)+...
   rho/2*sum_square_abs([real(W(45, 45)-W(45, 48)); imag(W(45, 45)-W(45, 48)); W(45, 45); W(48, 48)]-z_r2))
subject to
lambda_min(W) >= 0;
index.*(real((Index_gen'*(Pg+1j*Qg)-Sload)/mpc.baseMVA)-(diag(Gbus).*diag(W)+diag(Goffdiag*(real(W)-diag(diag(real(W))))')+  diag(Boffdiag*(imag(W))')))==0;
index.*(imag((Index_gen'*(Pg+1j*Qg)-Sload)/mpc.baseMVA)-(-diag(Bbus).*diag(W)+diag(-Boffdiag*(real(W)-diag(diag(real(W))))')+  diag(Goffdiag*(imag(W))')))==0;
Pmin<=Pg<=Pmax;
Qmin<=Qg<=Qmax;
VMIN2<=diag(W)<=VMAX2;
cvx_end
z_main1=[real(W(33, 33)-W(33, 34)); imag(W(33, 33)-W(33, 34)); W(33, 33); W(34, 34)];
z_main2=[real(W(45, 45)-W(45, 48)); imag(W(45, 45)-W(45, 48)); W(45, 45); W(48, 48)];

fuel=(Pg.*Pg)'*pr(:,1)+Pg'*pr(:,2)+sum(pr(:,3));

end
function [x_sub, z_r, lambda_sub]=get_init_sub(mpcac)
Pg=mpcac.gen(:,2);
Qg=mpcac.gen(:,3);
Vm=mpcac.bus(:,8);
VA=mpcac.bus(:,9);
x_sub= [Pg', Qg', Vm', VA'];
lambda_sub=zeros(4, 1);
z_r=[0, 0, 1, 1]';

end
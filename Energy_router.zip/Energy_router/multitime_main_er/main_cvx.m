
function [fuel_cost0, fuel_cost1, fuel_cost2, Vm1, Vm2]=main_cvx(mpc_main, mpcac1, mpcac2)



lambda_main=get_init_main();
[x_sub1, z_r1,  lambda_sub1]=get_init_sub(mpcac1);
[x_sub2, z_r2,  lambda_sub2]=get_init_sub(mpcac2);

iter=1;

while iter<=1000

[z_main1, z_main2, fuel_cost0]=update_x_main(z_r1, z_r2, lambda_main, mpc_main);
[x_sub1,z_r1, fuel_cost1, Vm1]=update_x_sub(z_main1, x_sub1, lambda_sub1, mpcac1, 1);
[x_sub2,z_r2, fuel_cost2, Vm2]=update_x_sub(z_main2, x_sub2, lambda_sub2, mpcac2, 2);

lambda_main=update_lambda_main(lambda_main, z_main1, z_main2, z_r1, z_r2);
lambda_sub1=update_lambda_sub(lambda_sub1, z_main1, z_r1);
lambda_sub2=update_lambda_sub(lambda_sub2, z_main2, z_r2);

[gamma1, gamma2]=get_gamma(z_main1, z_main2, z_r1, z_r2);

if  (gamma1<1e-5&&gamma2<1e-5)
    break;
end
sprintf('The current iteration is: %d', iter)
iter=iter+1;
end


end

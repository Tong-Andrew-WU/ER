function funs = load_mpc

funs.sub1_mpc=@sub1_mpc;

funs.sub2_mpc = @sub2_mpc;

funs.main_mpc = @main_mpc;
end


function [Plarge, Qlarge]=sub1_mpc(active_power, reactive_power, active_powerDC1, renew1) 
mpc_ext = case85sub_ac1;
ac_mpc_index=1:17;
index_mainac=mpc_ext.bus(ac_mpc_index, 1);
PD_bench=mpc_ext.bus(ac_mpc_index, 3);
QD_bench=mpc_ext.bus(ac_mpc_index, 4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PD_bench_mat=repmat(PD_bench', 480, 1);
QD_bench_mat=repmat(QD_bench', 480, 1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PD=active_power(:, index_mainac);
QD=reactive_power(:, index_mainac);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
active_power_max=repmat(max(PD), 480, 1);
reactive_power_max=repmat(max(QD), 480, 1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PD_real_sub=(PD./active_power_max).*PD_bench_mat;
QD_real_sub=(QD./reactive_power_max).*QD_bench_mat;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rew_mpc_index=28:31;
dc_mpc_index=32:35;
% index_rew=mpc_ext.bus(rew_mpc_index, 1);
% index_dc=mpc_ext.bus(dc_mpc_index, 1);
Prew=mpc_ext.bus(rew_mpc_index, 3);
Pdc=mpc_ext.bus(dc_mpc_index, 3);
%%%
Prew_mat=repmat(Prew', 480, 1);
Pdc_mat=repmat(Pdc', 480, 1);
%%%
active_powerDC1_max=repmat(max(active_powerDC1), 480, 1);
renew1_max=repmat(max(renew1), 480, 1);
%%%
Pdc_real_sub= (active_powerDC1./active_powerDC1_max).*Pdc_mat;
Prew_real_sub=(renew1./renew1_max).*        Prew_mat;

Plarge=zeros(480, size(mpc_ext.bus, 1));
Qlarge=zeros(480, size(mpc_ext.bus, 1));
Plarge(:, ac_mpc_index)=  PD_real_sub;
Plarge(:, 28:31)= Prew_real_sub;
Plarge(:, 32:35)= Pdc_real_sub;
Qlarge(:, ac_mpc_index)= QD_real_sub;

Plarge= fillmissing(Plarge,'constant',0);
Qlarge= fillmissing(Qlarge,'constant',0);

end

function [Plarge, Qlarge]=sub2_mpc(active_power, reactive_power, active_powerDC2, renew2) 
mpc_ext = case85sub_ac2;
ac_mpc_index=1:17;
index_mainac=mpc_ext.bus(ac_mpc_index, 1);
PD_bench=mpc_ext.bus(ac_mpc_index, 3);
QD_bench=mpc_ext.bus(ac_mpc_index, 4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PD_bench_mat=repmat(PD_bench', 480, 1);
QD_bench_mat=repmat(QD_bench', 480, 1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PD=active_power(:, index_mainac);
QD=reactive_power(:, index_mainac);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
active_power_max=repmat(max(PD), 480, 1);
reactive_power_max=repmat(max(QD), 480, 1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PD_real_sub=(PD./active_power_max).*PD_bench_mat;
QD_real_sub=(QD./reactive_power_max).*QD_bench_mat;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rew_mpc_index=[30, 32, 33, 35, 36];
dc_mpc_index= [31, 34, 37, 38, 39];
% index_rew=mpc_ext.bus(rew_mpc_index, 1);
% index_dc=mpc_ext.bus(dc_mpc_index, 1);
Prew=mpc_ext.bus(rew_mpc_index, 3);
Pdc=mpc_ext.bus(dc_mpc_index, 3);
%%%
Prew_mat=repmat(Prew', 480, 1);
Pdc_mat=repmat(Pdc', 480, 1);
%%%
active_powerDC2_max=repmat(max(active_powerDC2), 480, 1);
renew2_max=repmat(max(renew2), 480, 1);
%%%
Pdc_real_sub= (active_powerDC2./active_powerDC2_max).*Pdc_mat;
Prew_real_sub=(renew2./renew2_max).*        Prew_mat;

Plarge=zeros(480, size(mpc_ext.bus, 1));
Qlarge=zeros(480, size(mpc_ext.bus, 1));
Plarge(:, ac_mpc_index)=  PD_real_sub;
Plarge(:, rew_mpc_index)= Prew_real_sub;
Plarge(:, dc_mpc_index)= Pdc_real_sub;
Qlarge(:, ac_mpc_index)= QD_real_sub;
%
Plarge= fillmissing(Plarge,'constant',0);
Qlarge= fillmissing(Qlarge,'constant',0);
end

function [PD_real_main, QD_real_main]=main_mpc(active_power, reactive_power) 
mpc_ext = case85main_ac;
index_mainac=mpc_ext.bus(:, 1);
PD_bench=mpc_ext.bus(:, 3);
QD_bench=mpc_ext.bus(:, 4);

PD_bench_mat=repmat(PD_bench', 480, 1);
QD_bench_mat=repmat(QD_bench', 480, 1);

PD=active_power(:, index_mainac);
QD=reactive_power(:, index_mainac);



active_power_max=repmat(max(PD), 480, 1);
reactive_power_max=repmat(max(QD), 480, 1);

PD_real_main=(PD./active_power_max).*PD_bench_mat;
QD_real_main=(QD./reactive_power_max).*QD_bench_mat;
%%%
PD_real_main= fillmissing(PD_real_main,'constant',0);
QD_real_main= fillmissing(QD_real_main,'constant',0);
end

load('demand_p_renew.mat')
Time=48;
funs = load_mpc;
[PD_real_main, QD_real_main]=funs.main_mpc(active_power, reactive_power);
[PD_real_sub1, QD_real_sub1]=funs.sub1_mpc(active_power, reactive_power, active_powerDC1, renew1);
[PD_real_sub2, QD_real_sub2]=funs.sub2_mpc(active_power, reactive_power, active_powerDC2, renew2);

mpc_main = case85main_ac;
mpcac1 = case85sub_ac1;
mpcac2 = case85sub_ac2;
Index_main=mpc_main.bus(:, 1);
Index_sub1=mpcac1.bus(:, 1);
Index_sub2=mpcac2.bus(:, 1);

mpcac_org = case85main_ac_org;
Pload=zeros(480, size(mpcac_org.bus, 1));
Qload=zeros(480, size(mpcac_org.bus, 1));

Pload(:, Index_main)=PD_real_main;
Qload(:, Index_main)=QD_real_main;
Pload(:, Index_sub1)=PD_real_sub1;
Qload(:, Index_sub1)=QD_real_sub1;
Pload(:, Index_sub2)=PD_real_sub2;
Qload(:, Index_sub2)=QD_real_sub2;


fuel_cost_main=zeros(Time, 1);
fuel_cost_sub1=zeros(Time, 1);
fuel_cost_sub2=zeros(Time, 1);
Vm_tot=zeros(Time, size(mpcac_org.bus, 1));


for i=1:Time

mpcac_org.bus(:, 3)=(Pload(i, :))';
mpcac_org.bus(:, 4)=(Qload(i, :))';



mpcac_org_int=ext2int(mpcac_org);



[fuel_cost0, fuel_cost1, fuel_cost2, Vm]=update_x_sub(mpcac_org_int);
fuel_cost_main(i)=fuel_cost0;
fuel_cost_sub1(i)=fuel_cost1;
fuel_cost_sub2(i)=fuel_cost2;
Vm_tot(i, :)=Vm;
end

save('multitime_Aggregate_er.mat', 'fuel_cost_main', 'fuel_cost_sub1','fuel_cost_sub2','Vm_tot')


function para=get_para()
             mpc= case85main_ac_org;
             mpcint=ext2int(mpc);
             index_Qmat=[93:110, 121:142];
             Qmat=zeros(size(index_Qmat, 2), size(mpc.bus, 1));
             row=mpcint.branch(index_Qmat,1);
             col=mpcint.branch(index_Qmat,2);
             index_row=sub2ind(size(Qmat), 1:size(index_Qmat, 2), row');
             index_col=sub2ind(size(Qmat), 1:size(index_Qmat, 2), col');
             Qmat(index_row)=1;
             Qmat(index_col)=-1;
             para.Qmat=Qmat;
%              %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%% [PG_AC, QG_AC, VM_AC, VA_AC]
%           x0 = [mpcac.gen(:,2)', mpcac.gen(:,3)', mpcac.bus(:, 8)', mpcac.bus(:, 9)'];
             Aeq=zeros(size(index_Qmat, 2), 2*(size(mpcint.bus, 1)+size(mpcint.gen, 1)));
             Aeq(:,(2*size(mpcint.gen, 1)+size(mpcint.bus, 1)+1):2*(size(mpcint.bus, 1)+size(mpcint.gen, 1)))=Qmat;
             beq=zeros(size(index_Qmat, 2), 1);
             para.Aeq=Aeq;
             para.beq=beq;
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             index_VmDd=[93:100, 121:130];
             Vm2D=zeros(size(index_VmDd, 2), size(mpc.bus, 1));
             row2D=mpcint.branch(index_VmDd,1);
             col2D=mpcint.branch(index_VmDd,2);
             index_row2D=sub2ind(size(Vm2D), 1:size(index_VmDd, 2), row2D');
             index_col2D=sub2ind(size(Vm2D), 1:size(index_VmDd, 2), col2D');
             Vm2D(index_row2D)=1;
             Vm2D(index_col2D)=-2/sqrt(3);
             A=zeros(size(index_VmDd, 2), 2*(size(mpc.bus, 1)+size(mpc.gen, 1)));
             A(:,(2*size(mpc.gen, 1)+1):(2*size(mpc.gen, 1)+size(mpc.bus, 1)))=Vm2D;
             b=zeros(size(index_VmDd, 2), 1);
             para.A=A;
             para.b=b;


end

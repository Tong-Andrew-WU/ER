function [c, ceq] = wconfun_AC(x, mpc)
% %%%%% [PG_AC, QG_AC, VM_AC, VA_AC, PG_DC, VM_DC]
% x0 = [mpcac.gen(:,2)', mpcac.gen(:,3)', mpcac.bus(:, 8)', mpcac.bus(:, 9)', mpcdc.gen(:, 2)', mpcdc.bus(:, 5)'];


ngen=size(mpc.gen,1);
nbus=size(mpc.bus,1);
PG=x(1:ngen)';
QG=x(ngen+1: 2*ngen)';
Vm=x(2*ngen+1: 2*ngen+nbus)';
Va=x(2*ngen+nbus+1: 2*ngen+2*nbus)';
Ybus = makeYbus(mpc);

%%%%nonlinear equality constraint%%%%
baseMVA=mpc.baseMVA;
gen_x=mpc.gen;
gen_x(:,2)=PG;
gen_x(:,3)=QG;
Sbus=makeSbus(baseMVA, mpc.bus, gen_x);
Vcplx=Vm.*exp(1j.*Va);
mis=Sbus-Vcplx.*conj(Ybus*Vcplx);



ceq=zeros(nbus*2,1);
ceq(1:nbus)=real(mis);
ceq(nbus+1:nbus+nbus)=imag(mis);

c=[];
end
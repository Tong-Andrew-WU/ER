
mpc = case85main_ac;
mpcac=ext2int(mpc);

ngen=size(mpcac.gen,1);
nbus=size(mpcac.bus,1);

Tamin=-2*pi*ones(1,nbus);
Tamax=2*pi*ones(1,nbus);
%%%% [PG_AC, QG_AC, VM_AC, VA_AC]
x0 = [mpcac.gen(:,2)', mpcac.gen(:,3)', mpcac.bus(:, 8)', mpcac.bus(:, 9)'];
lb = [mpcac.gen(:,10)', mpcac.gen(:,5)', mpcac.bus(:,13)', Tamin];
ub = [mpcac.gen(:,9)', mpcac.gen(:,4)', mpcac.bus(:,12)', Tamax];

para=get_para();
Aeq=para.Aeq;
beq=para.beq;

A=para.A;
b=para.b;

options = optimset('MaxIter',3000, 'MaxFunEvals',300000,'TolFun', 1e-8, 'Algorithm','sqp', 'display', 'iter');
[x, fval, exitflag, output]=fmincon(@(x)wobjfun_AC(x, mpcac), x0, A, b, Aeq, beq, lb, ub,...
    @(x)wconfun_AC(x, mpcac), options);


% end
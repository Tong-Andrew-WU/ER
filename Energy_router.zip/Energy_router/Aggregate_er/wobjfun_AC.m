function f=wobjfun_AC(x, mpcac)
pr=mpcac.gencost(:,5:7);  % x implies the cost of the generator.
ngen=size(mpcac.gen,1);
PG=x(1:ngen);
f=(PG.*PG)*pr(:,1)+PG*(pr(:,2))+sum(pr(:,3));
end
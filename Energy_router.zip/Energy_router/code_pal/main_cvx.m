% For  loop check residential gap
% cvx to solve main
% give variables from main to subproblem
% solve subproblem and return variables to master problem



mpc_ext = case85main_ac;
mpc_main=ext2int(mpc_ext);

mpcac1_ext = case85sub_ac1;
mpcac1=ext2int(mpcac1_ext);

mpcac2_ext = case85sub_ac2;
mpcac2=ext2int(mpcac2_ext);



lambda_main=get_init_main();
[x_sub1, z_r1,  lambda_sub1]=get_init_sub(mpcac1);
[x_sub2, z_r2,  lambda_sub2]=get_init_sub(mpcac2);

iter=1;
numsub=2;
lambda_sub{1}=lambda_sub1;
lambda_sub{2}=lambda_sub2;
z_r{1}=z_r1;
z_r{2}=z_r2;
mpcac{1}=mpcac1;
mpcac{2}=mpcac2;
x_sub{1}=x_sub1;
x_sub{2}=x_sub2;

while iter<=1000

[z_main1, z_main2]=update_x_main(z_r{1}, z_r{2}, lambda_main, mpc_main);
z_main{1}=z_main1;
z_main{2}=z_main2;
parfor i=1:numsub
[x_sub{i},z_r{i}]=update_x_sub(z_main{i}, x_sub{i}, lambda_sub{i}, mpcac{i}, i);
lambda_sub{i}=update_lambda_sub(lambda_sub{i}, z_main{i}, z_r{i});
end

lambda_main=update_lambda_main(lambda_main, z_main{1}, z_main{2}, z_r{1}, z_r{2});
[gamma1, gamma2]=get_gamma(z_main{1}, z_main{2}, z_r{1}, z_r{2});

if  (gamma1<1e-7&&gamma2<1e-7)
    break;
end
sprintf('The current iteration is: %d', iter)
iter=iter+1;
end

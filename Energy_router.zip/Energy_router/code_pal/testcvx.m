mpc=loadcase(case30);

Ybus=makeYbus(mpc);
Gbus=real(Ybus);
Gdiag=diag(Gbus);
Goffdiag=Gbus-diag(Gdiag);

Bbus=imag(Ybus);
Bdiag=diag(Bbus);
Boffdiag=Bbus-diag(Bdiag);

VMIN2=mpc.bus(:,13).^2;
VMAX2=mpc.bus(:,12).^2;
Pmax=mpc.gen(:,9);
Pmin=mpc.gen(:,10);
Qmax=mpc.gen(:,4);
Qmin=mpc.gen(:,5);
Sload=mpc.bus(:,3)+1j*mpc.bus(:,4);
pr=mpc.gencost(:,5:7); 
n=size(mpc.bus, 1);
m=size(mpc.gen, 1);

Index_gen=zeros(size(mpc.gen(:,1),1), size(mpc.bus(:,1),1));
Select_index=(1:size(mpc.gen(:,1),1))' + (mpc.gen(:,1)-1)*size(mpc.gen(:,1),1);
Index_gen(Select_index)=1;


cvx_begin sdp quiet
variable  W(n, n) hermitian
variable  Pg(m)
variable  Qg(m)

minimize ((Pg.*Pg)'*pr(:,1)+Pg'*pr(:,2)+sum(pr(:,3)))
subject to
lambda_min(W) >= 0;
real((Index_gen'*(Pg+1j*Qg)-Sload)/mpc.baseMVA)-(diag(Gbus).*diag(W)+diag(Goffdiag*(real(W)-diag(diag(real(W))))')+  diag(Boffdiag*(imag(W))'))==0;
imag((Index_gen'*(Pg+1j*Qg)-Sload)/mpc.baseMVA)-(-diag(Bbus).*diag(W)+diag(-Boffdiag*(real(W)-diag(diag(real(W))))')+  diag(Goffdiag*(imag(W))'))==0;
Pmin<=Pg<=Pmax;
Qmin<=Qg<=Qmax;
VMIN2<=diag(W)<=VMAX2;
cvx_end
